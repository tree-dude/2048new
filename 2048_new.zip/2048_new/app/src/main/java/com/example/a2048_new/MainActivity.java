package com.example.a2048_new;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelStoreOwner;

import android.app.AutomaticZenRule;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    RelativeLayout rllt;
    TextView test;
    SwipeListener swlis;
    TextView[][] table = new TextView[4][4];
    public static int rnd(int min, int max) {
        max -= min;
        return (int) (Math.random() * ++max) + min;
    }

    TextView i11 = findViewById(R.id.i11);
    TextView i12 = findViewById(R.id.i12);
    TextView i13 = findViewById(R.id.i13);
    TextView i14 = findViewById(R.id.i14);

    TextView i21 = findViewById(R.id.i21);
    TextView i22 = findViewById(R.id.i22);
    TextView i23 = findViewById(R.id.i23);
    TextView i24 = findViewById(R.id.i24);

    TextView i31 = findViewById(R.id.i31);
    TextView i32 = findViewById(R.id.i32);
    TextView i33 = findViewById(R.id.i33);
    TextView i34 = findViewById(R.id.i34);

    TextView i41 = findViewById(R.id.i41);
    TextView i42 = findViewById(R.id.i42);
    TextView i43 = findViewById(R.id.i43);
    TextView i44 = findViewById(R.id.i44);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rllt = findViewById(R.id.rllt);

        table[0][0] = i11;
        table[0][1] = i12;
        table[0][2] = i13;
        table[0][3] = i14;

        table[1][0] = i21;
        table[1][1] = i22;
        table[1][2] = i23;
        table[1][3] = i24;

        table[2][0] = i31;
        table[2][1] = i32;
        table[2][2] = i33;
        table[2][3] = i34;

        table[3][0] = i41;
        table[3][1] = i42;
        table[3][2] = i43;
        table[3][3] = i44;

        SwipeListener swipeListener = new SwipeListener(rllt);

            onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            int tmp3 = 0;

            Button play = findViewById(R.id.start);

        View.OnClickListener startb = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int x1 = rnd(0, 3);
                int y1 = rnd(0, 3);
                table[x1][y1].setText("2");
                boolean setSuccessful = false;
                while (!setSuccessful) {
                    int x2 = rnd(0, 3);
                    int y2 = rnd(0, 3);
                    if (x1 != x2 || y1 != y2) {
                        table[x2][y2].setText("2");
                        setSuccessful = true;
                    }
                }
                play.setEnabled(false);
            }
        };
    }

    public class SwipeListener implements View.OnTouchListener {

        GestureDetector gstdt;

        SwipeListener(View view){
            int threshold = 100;
            int vel_threshold = 100;
            GestureDetector.SimpleOnGestureListener listener = new GestureDetector.SimpleOnGestureListener(){

                        @Override
                        public boolean onDown(MotionEvent e){
                            return true;
                        }

                        @Override
                        public boolean onFling(MotionEvent e1, MotionEvent e2, float vel_X, float vel_Y){
                            float xDiff = e2.getX() - e1.getX();
                            float yDiff = e2.getY() - e1.getY();
                            try{
                                if(Math.abs(xDiff)>Math.abs(yDiff)){
                                    if(Math.abs(xDiff)>threshold && Math.abs(vel_X)>vel_threshold){
                                         if(xDiff >0){
                                             if(validation()){
                                                 right(i11, i12, i13, i14);
                                                 right(i21, i22, i23, i24);
                                                 right(i31, i32, i33, i34);
                                                 right(i41, i42, i43, i44);
                                             }
                                         }else{
                                             //"left");
                                         }
                                         return true;
                                    }
                                }else{
                                    if(Math.abs(yDiff)>threshold && Math.abs(vel_Y)>vel_threshold){
                                        if(yDiff >0){
                                            //test.setText("down");
                                        }else{
                                            //test.setText("up");
                                        }
                                        return true;
                                    }
                                }
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                            return false;
                        }
                    };
            gstdt = new GestureDetector(listener);
            view.setOnTouchListener(this);
        }

        @Override
        public boolean onTouch(View view, MotionEvent Mevent) {
            return gstdt.onTouchEvent(Mevent);
        }
    }
    public boolean validation() {
        TextView tmpView;
        int z = 0;
        for (int i = 0; i < 4; i++) {
            for (int u = 0; u < 4; u++) {
                tmpView = table[i][u];
                if (Integer.parseInt(tmpView.getText().toString()) == 0) {
                    table[i][u].setBackgroundResource(R.color.prog0);
                    z++;
                }
                if (Integer.parseInt(tmpView.getText().toString()) == 2) {
                    table[i][u].setBackgroundResource(R.color.prog1);
                }
                if (Integer.parseInt(tmpView.getText().toString()) == 4) {
                    table[i][u].setBackgroundResource(R.color.prog2);
                }
                if (Integer.parseInt(tmpView.getText().toString()) == 8) {
                    table[i][u].setBackgroundResource(R.color.prog3);
                }
                if (Integer.parseInt(tmpView.getText().toString()) == 16) {
                    table[i][u].setBackgroundResource(R.color.prog4);
                }
                if (Integer.parseInt(tmpView.getText().toString()) == 32) {
                    table[i][u].setBackgroundResource(R.color.prog5);
                }
                if (Integer.parseInt(tmpView.getText().toString()) == 64) {
                    table[i][u].setBackgroundResource(R.color.prog6);
                }
                if (Integer.parseInt(tmpView.getText().toString()) == 128) {
                    table[i][u].setBackgroundResource(R.color.prog7);
                }
                if (Integer.parseInt(tmpView.getText().toString()) == 256) {
                    table[i][u].setBackgroundResource(R.color.prog8);
                }
                if (Integer.parseInt(tmpView.getText().toString()) == 512) {
                    table[i][u].setBackgroundResource(R.color.prog9);
                }
                if (Integer.parseInt(tmpView.getText().toString()) == 1024) {
                    table[i][u].setBackgroundResource(R.color.prog10);
                }
                if (Integer.parseInt(tmpView.getText().toString()) == 2048) {
                    table[i][u].setBackgroundResource(R.color.prog11);
                }

            }
        }

        int tmpaut = 0;

        for (int j = 0; j < 4; j++) {
            for (int g = 0; g < 4; g++) {
                if (j == 0 && g == 0) {
                    if (table[0][0] == table[0][1] || table[0][0] == table[1][0]) {
                        tmpaut++;
                    }
                }
                if (j == 0 && g == 3) {
                    if (table[0][3] == table[0][2] || table[0][3] == table[1][3]) {
                        tmpaut++;
                    }
                }
                if (j == 0 && g == 0) {
                    if (table[3][0] == table[3][1] || table[3][0] == table[2][0]) {
                        tmpaut++;
                    }
                }
                if (j == 0 && g == 0) {
                    if (table[3][3] == table[3][2] || table[3][3] == table[2][3]) {
                        tmpaut++;
                    }
                }


                if ((j == 1 || j == 2) && (g == 0)) {
                    if (table[j][g] == table[j + 1][g] || table[j][g] == table[j - 1][g] || table[j][g] == table[j][g + 1]) {
                        tmpaut++;
                    }
                }
                if ((j == 1 || j == 2) && (g == 3)) {
                    if (table[j][g] == table[j + 1][g] || table[j][g] == table[j - 1][g] || table[j][g] == table[j][g - 1]) {
                        tmpaut++;
                    }
                }
                if ((g == 1 || g == 2) && (j == 0)) {
                    if (table[j][g] == table[j][g + 1] || table[j][g] == table[j][g - 1] || table[j][g] == table[j + 1][g]) {
                        tmpaut++;
                    }
                }
                if ((g == 1 || g == 2) && (j == 3)) {
                    if (table[j][g] == table[j][g + 1] || table[j][g] == table[j][g - 1] || table[j][g] == table[j - 1][g]) {
                        tmpaut++;
                    }
                }


                if ((g == 1 || g == 2) && (j == 1 || j == 2)) {
                    if (table[j][g] == table[j][g + 1] || table[j][g] == table[j][g - 1] || table[j][g] == table[j + 1][g] || table[j][g] == table[j - 1][g]) {
                        tmpaut++;
                    }
                }
            }
        }


        return true;
    };

    public void right(TextView i1, TextView i2, TextView i3, TextView i4){
        if (i1 == i2 && i2 == i3 && i3 == i4){
            i4.setText(String.valueOf(Integer.parseInt(i4.getText().toString())*2));
            i3.setText(String.valueOf(Integer.parseInt(i3.getText().toString())*2));
            i2.setText("0");
            i1.setText("0");
        }

        if (i1 != i2 && i2 != i3 && i3 == i4){
            i4.setText(String.valueOf(Integer.parseInt(i4.getText().toString())*2));
            i3.setText(i2.getText());
            i2.setText(i1.getText());
            i1.setText("0");
        }

        if (i1 != i2 && i2 == i3 && i3 != i4){
            i3.setText(String.valueOf(Integer.parseInt(i2.getText().toString())*2));
            i2.setText(i1.getText());
            i1.setText("0");
        }

        if (i1 == i2 && i2 != i3 && i3 != i4){
            i2.setText(String.valueOf(Integer.parseInt(i1.getText().toString())*2));
            i1.setText("0");
        }

        if (i1 == i2 && i2 != i3 && i3 == i4){
            i4.setText(String.valueOf(Integer.parseInt(i4.getText().toString())*2));
            i3.setText(String.valueOf(Integer.parseInt(i2.getText().toString())*2));
            i2.setText("0");
            i1.setText("0");
        }
    };



}